torch_geometric.data
====================

.. automodule:: torch_geometric.data
    :members:
    :special-members:
    :undoc-members:
