__version__ = '1.1.2'

__all__ = ['__version__']
