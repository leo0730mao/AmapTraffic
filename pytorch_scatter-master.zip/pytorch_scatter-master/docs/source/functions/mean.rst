Scatter Mean
============

.. automodule:: torch_scatter

.. autofunction:: scatter_mean
