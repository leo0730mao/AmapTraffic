Scatter Add
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_add
