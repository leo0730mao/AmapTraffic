Scatter Max
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_max
