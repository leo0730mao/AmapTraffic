Scatter Std
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_std
