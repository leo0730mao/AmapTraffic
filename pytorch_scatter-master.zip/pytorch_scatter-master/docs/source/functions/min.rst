Scatter Min
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_min
