Scatter Mul
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_mul
