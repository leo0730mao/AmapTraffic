Scatter Sub
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_sub
