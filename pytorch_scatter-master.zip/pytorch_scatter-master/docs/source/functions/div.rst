Scatter Div
===========

.. automodule:: torch_scatter

.. autofunction:: scatter_div
